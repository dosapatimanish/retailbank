/* Vo class of personal details */
package com.intellect.retail.modelbank.retailbank.Model;

public class PersonalDetails {

    private String first_name;
    private String last_name;
    private String father_name;
    private String pan_number;
    private String state;
    private String city;
    private String permanent_address;
    private String email;
    private String country;
    private String present_address;

    public PersonalDetails(String first_name, String last_name, String father_name, String pan_number, String state,
            String city, String permanent_address, String email, String country, String present_address) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.father_name = father_name;
        this.pan_number = pan_number;
        this.state = state;
        this.city = city;
        this.permanent_address = permanent_address;
        this.email = email;
        this.country = country;
        this.present_address = present_address;
    }

    public PersonalDetails() {
        super();
    }

    @Override
    public String toString() {
        return "PersonalDetails [first_name=" + first_name + ", last_name=" + last_name + ", father_name=" + father_name
                + ", pan_number=" + pan_number + ", state=" + state + ", city=" + city + ", permanent_address="
                + permanent_address + ", email=" + email + ", country=" + country + ", present_address="
                + present_address + "]";
    }

    public String getFirst_name() {
        return this.first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return this.last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getFather_name() {
        return this.father_name;
    }

    public void setFather_name(String father_name) {
        this.father_name = father_name;
    }

    public String getPan_number() {
        return this.pan_number;
    }

    public void setPan_number(String pan_number) {
        this.pan_number = pan_number;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPermanent_address() {
        return this.permanent_address;
    }

    public void setPermanent_address(String permanent_address) {
        this.permanent_address = permanent_address;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPresent_address() {
        return this.present_address;
    }

    public void setPresent_address(String present_address) {
        this.present_address = present_address;
    }

}
