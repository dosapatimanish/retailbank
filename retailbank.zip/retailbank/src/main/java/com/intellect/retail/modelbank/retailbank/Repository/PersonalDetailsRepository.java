/*getting details from database */
package com.intellect.retail.modelbank.retailbank.Repository;

import java.util.List;

import javax.xml.soap.Detail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.intellect.retail.modelbank.retailbank.Model.PersonalDetails;

@Repository
public class PersonalDetailsRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int savePersonalDetails(PersonalDetails Details) {

        System.out.println("@@@@Inside repo");
        return jdbcTemplate.update(
                "insert into personaldetails(first_name,last_name,father_name,pan_number,state,city,permanent_address,email,country,present_address) values(?,?,?,?,?,?,?,?,?,?)",
                Details.getFirst_name(), Details.getLast_name(), Details.getFather_name(), Details.getPan_number(),
                Details.getState(), Details.getPermanent_address(), Details.getEmail(), Details.getCountry(),
                Details.getPresent_address());
    }

    public List<PersonalDetails> check_name_pan() {

        return jdbcTemplate.query("select first_name,last_name,pan_number from personaldetails",
                (resultSet, rowNum) -> new PersonalDetails(resultSet.getString("first_name"),
                        resultSet.getString("last_name"), null, resultSet.getString("pan_number"), null, null, null,
                        null,
                        null, null));
    }

}
