/* this service takes mobile number & dob and checks weather the mobile number is already registered in the db or not and also checks weather the number is equal to 10 digits or not */
package com.intellect.retail.modelbank.retailbank.Service;

import java.util.*;
// import java.time.format.DateTimeFormatter;
// import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.intellect.retail.modelbank.retailbank.Model.Mobdob;
import com.intellect.retail.modelbank.retailbank.Repository.MobdobRepository;

@Service
public class MobdobService {

    @Autowired
    MobdobRepository mobdobRepository;

    private Mobdob mobdob;

    public char checkmob_flag = 'Y';
    public char checkpan_flag = 'Y';

    public void check_names() {
        List<Mobdob> s = mobdobRepository.check_mob_dob();
        int i;
        for (i = 0; i < s.size(); i++) {
            if (s.get(i).getMobile() == this.mobdob.getMobile()) {
                checkmob_flag = 'Y';
                return;
            }
        }
        if (i == s.size()) {
            checkmob_flag = 'N';
        }

    }

    public int addmobdobdetails(Mobdob mobdobdetails) {
        this.mobdob = mobdobdetails;

        check_names();

        if (this.mobdob.getMobile().length() == 10 && this.checkmob_flag == 'N')
            return mobdobRepository.saveMobDob(this.mobdob);

        return 0;

    }
}
