/* getting details from database */
package com.intellect.retail.modelbank.retailbank.Repository;


import java.util.List;

import javax.xml.soap.Detail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.intellect.retail.modelbank.retailbank.Model.Mobdob;;

@Repository
public class MobdobRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int saveMobDob(Mobdob mobdob) {

        System.out.println("@@@@Inside repo");
        return jdbcTemplate.update(
                "insert into mobdob(mobile,dob) values(?,?)",
                mobdob.getMobile(),mobdob.getDate1());

    }

    public List<Mobdob> check_mob_dob() {

        return jdbcTemplate.query("select * from mobdob",
                (resultSet, rowNum) -> new Mobdob(resultSet.getString("mobile"),
                        resultSet.getString("date1")));
    }

    
}
