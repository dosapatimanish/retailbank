/* Vo class of Mobilenumber & dateofbirth */

package com.intellect.retail.modelbank.retailbank.Model;

public class Mobdob {

    private String mobile;
    private String date1;

    
    
    public Mobdob(String mobile, String date1) {
        this.mobile = mobile;
        this.date1 = date1;
    }

    
    
    public Mobdob() {
        super();
    }

    



    @Override
    public String toString() {
        return "Mobdob [mobile=" + mobile + ", date1=" + date1 + "]";
    }



    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public String getDate1() {
        return date1;
    }
    public void setDate1(String date1) {
        this.date1 = date1;
    }

    
}


    
        

    

    

    
        
    

    
        
    

