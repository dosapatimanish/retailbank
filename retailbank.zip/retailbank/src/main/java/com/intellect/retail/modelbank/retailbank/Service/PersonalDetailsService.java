/* checks weather the number is already present in the database or not & checks the length of name & also checks weather the pan number is present in the db or not */
package com.intellect.retail.modelbank.retailbank.Service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.intellect.retail.modelbank.retailbank.Model.PersonalDetails;
import com.intellect.retail.modelbank.retailbank.Repository.PersonalDetailsRepository;

@Service
public class PersonalDetailsService {

    @Autowired
    PersonalDetailsRepository personalDetailsRepository;

    private PersonalDetails Details;

    public char checkname_flag = 'Y';
    public char checkpan_flag = 'Y';

    public void check_names() {
        List<PersonalDetails> s = personalDetailsRepository.check_name_pan();
        int i;
        for (i = 0; i < s.size(); i++) {
            if (s.get(i).getFirst_name() + s.get(i).getLast_name() == this.Details.getFirst_name()
                    + this.Details.getLast_name()) {
                checkname_flag = 'Y';
                return;
            }
        }
        if (i == s.size()) {
            checkname_flag = 'N';
        }
        int j;
        for (j = 0; j < s.size(); j++) {
            if (s.get(i).getPan_number() == this.Details.getPan_number()) {
                checkpan_flag = 'Y';
                return;
            }
        }

        if (j == s.size()) {
            checkpan_flag = 'N';
        }

    }

    public int addpersonaldetails(PersonalDetails Details) {
        this.Details = Details;

        check_names();

        if ((this.Details.getFirst_name() + this.Details.getLast_name()).length() < 50 && checkname_flag == 'N'
                && checkpan_flag == 'N')
            return personalDetailsRepository.savePersonalDetails(Details);

        return 0;

    }
}
