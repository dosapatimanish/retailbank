/* Initial Controller get MobileNumber & Date of birth */
package com.intellect.retail.modelbank.retailbank.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import com.intellect.retail.modelbank.retailbank.Service.MobdobService;
import com.intellect.retail.modelbank.retailbank.Model.Mobdob;

@RestController("/")
public class MobdobController {

@Autowired
    MobdobService mobdobService;

    // @GetMapping("/get")
    // public List<PersonalDetails> getPersonalDetails(){
    // System.out.println("Inside getCartDetails");
    // return personalDetailsService.addpersonaldetails();
    // }

    //Path to add mobile number & dob

    @PostMapping("/add")
    public int addCartDetails(@RequestBody Mobdob mobdob) {

        System.out.println("@@@Inside add");
        return mobdobService.addmobdobdetails(mobdob);
    }

    // @PutMapping("/update")
    // public int updateCartDetails(@RequestBody Appointment appointment) {
    // return appointmentService.updateCartDetails(appointment);
    // }

    // @DeleteMapping("/delete/{phono}")
    // public int deleteCartDetails(@PathVariable String phono) {
    // System.out.println("removing " + phono);
    // return appointmentService.deleteCartDetails(phono);
    // }

    
}
