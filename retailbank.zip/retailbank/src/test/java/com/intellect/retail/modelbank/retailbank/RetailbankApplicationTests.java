package com.intellect.retail.modelbank.retailbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
